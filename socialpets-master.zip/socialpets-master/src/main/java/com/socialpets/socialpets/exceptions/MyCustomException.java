package com.socialpets.socialpets.exceptions;

public class MyCustomException extends Exception {
    
    public MyCustomException(String CustomMessage){
        super(CustomMessage);
    }
}
