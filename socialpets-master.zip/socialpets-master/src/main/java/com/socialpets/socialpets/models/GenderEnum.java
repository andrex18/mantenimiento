package com.socialpets.socialpets.models;

public enum GenderEnum {
    HEMBRA, MACHO
}
