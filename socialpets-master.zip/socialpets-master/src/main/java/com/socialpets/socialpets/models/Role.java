package com.socialpets.socialpets.models;

public enum Role {
    ADMINISTRADOR,
    FUNDACION,
    SALVADOR
}
